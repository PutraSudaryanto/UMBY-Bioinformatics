close all;clear all;clc;

folder = 'data_latih';
namafile = dir([folder '/*.bmp']);
for k = 1:length(namafile)
    filename = [folder '/' namafile(k).name];
    A = imread(filename); 
    %A=imread('data_latih/kurap2.bmp');
    R = A(:,:,1);
    G = A(:,:,2);
    B = A(:,:,3);
    %YUV
    M = (0.299*R)+(0.587*G)+(0.114*B);
    [m,n]=size(M);

    %invers
    for i=1:m,
        for j=1:n,
            cb(i,j)=255-M(i,j);
        end,
    end,

    %kontras
    for i=1:m,
        for j=1:n,
            cb1(i,j)=cb(i,j);
            if (cb1(i,j)>255)
                cb2(i,j)=255;
            else
                cb2(i,j)=cb1(i,j);
            end,
        end,
    end,
    imwrite(cb2,['img_dt/dt_',num2str(k),'.jpg']);
    [a, b] = size(cb2);

    % Hitung frekuensi aras keabuan
    L = 256;
    Frek = zeros(L,1);
    F = double(cb2);
    for i = 1 : a
        for j = 1 : b
            intensitas = F(i,j); 

            Frek(intensitas+1) = Frek(intensitas+1) + 1;
        end
    end

    % Hitung probabilitas
    jum_piksel = a * b;
    for i=0 : L-1
        Prob(i+1) = Frek(i+1) / jum_piksel;
    end

    % Hitung mu
    mu = 0;
    for i=0 : L-1
        mu = mu + i * Prob(i+1);    
    end

    % Hitung deviasi standar
    varians = 0;
    for i=0 : L-1
       varians = varians + (i - mu)^2 * Prob(i+1);    
    end

    deviasi = sqrt(varians);
    varians_n = varians / (L-1)^2; % Normalisasi

    % Energi (Keseragaman)
    energi = 0;
    for i=0 : L-1
       energi = energi + Prob(i+1)^2;    
    end
    
    % Hitung R atau Smoothness
    smoothness = 1 - 1 / (1 + varians_n);

    mu;
    deviasi;
    energi;
    smoothness;
    
    %warna
    RGB = double(A);
    [m,n,d] = size(A);
    % Rata2
    jum_r=0;
    jum_g=0;
    jum_b=0;
    jum_piksel = m * n;
    for baris = 1:m
        for kolom = 1:n
              jum_r = jum_r + RGB(baris, kolom, 1);
              jum_g = jum_g + RGB(baris, kolom, 2);
         end
    end
    % Hitung rerata
    mean_r = jum_r / jum_piksel;
    mean_g = jum_g / jum_piksel;
    
    % Write data tekstur dan warna
    data = [mu deviasi energi smoothness mean_r mean_g];

    save data_latih.txt data -ascii -append;
end
disp('Data Save');