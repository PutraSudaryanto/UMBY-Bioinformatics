clc;
clear all;
%KELAS 1
E=imread('1.1.bmp');
%figure, imshow(E)
     R=E(:,:,1);
     G=E(:,:,2);
     B=E(:,:,3);
%ubah ke YUV
     V=(0.299*R)+(0.548*G)+(0.114*B);

V=imresize(V,[300 300]);
[k l]=size(V);
%figure, imshow(V)
 V=double(V);

%Deteksi EDGE pake Sobel
for x=2:k-1
    for y=2:l-1
       
         W(x,y)=sqrt((-1*V((x-1),(y-1))-2*V(x,(y-1))-1*V((x+1),(y-1))+...
            1*V((x-1),(y+1))+2*V(x,(y+1))+1*V((x+1),(y+1))).^2+...
            (1*V((x-1),(y-1))+2*V((x-1),y)+1*V((x-1),(y+1))-...
            1*V((x+1),(y-1))-2*V((x+1),y)-1*V((x+1),(y+1))).^2);        

    end
end
W=uint8(W);
%figure, imshow(W);


D=[];
c=0;
for m=1:5:k
    for n=1:5:l
     a=0;
     b=0;
        if (((m+4) < k) && ((n+4) < l)) 
        
         for i=m:(m+4)
             for j=n:(n+4)
                W(i,j);
                a=a+W(i,j);
             end
         end
            b=a/25;
            c=c+1;
            D=[D b];
        end
    end
end
D;
%figure, plot(D)



%KELAS 2
E=imread('5.1.bmp');
%figure, imshow(E)
     R=E(:,:,1);
     G=E(:,:,2);
     B=E(:,:,3);
%ubah ke YUV
     V=(0.299*R)+(0.548*G)+(0.114*B);

V=imresize(V,[300 300]);
[k l]=size(V);
%figure, imshow(V)
 V=double(V);

%Deteksi EDGE pake Sobel
for x=2:k-1
    for y=2:l-1
       
         W(x,y)=sqrt((-1*V((x-1),(y-1))-2*V(x,(y-1))-1*V((x+1),(y-1))+...
            1*V((x-1),(y+1))+2*V(x,(y+1))+1*V((x+1),(y+1))).^2+...
            (1*V((x-1),(y-1))+2*V((x-1),y)+1*V((x-1),(y+1))-...
            1*V((x+1),(y-1))-2*V((x+1),y)-1*V((x+1),(y+1))).^2);        

    end
end
W=uint8(W);
%figure, imshow(W);


P=[];
c=0;
for m=1:5:k
    for n=1:5:l
     a=0;
     b=0;
        if (((m+4) < k) && ((n+4) < l)) 
        
         for i=m:(m+4)
             for j=n:(n+4)
                W(i,j);
                a=a+W(i,j);
             end
         end
            b=a/25;
            c=c+1;
            P=[P b];
        end
    end
end
P;
%figure, plot(P)


%UJI
E=imread('5.3.bmp');
%figure, imshow(E)
     R=E(:,:,1);
     G=E(:,:,2);
     B=E(:,:,3);
%ubah ke YUV
     V=(0.299*R)+(0.548*G)+(0.114*B);

V=imresize(V,[300 300]);
[k l]=size(V);
%figure, imshow(V)

 V=double(V);
%Deteksi EDGE pake Sobel
for x=2:k-1
    for y=2:l-1
       
         W(x,y)=sqrt((-1*V((x-1),(y-1))-2*V(x,(y-1))-1*V((x+1),(y-1))+...
            1*V((x-1),(y+1))+2*V(x,(y+1))+1*V((x+1),(y+1))).^2+...
            (1*V((x-1),(y-1))+2*V((x-1),y)+1*V((x-1),(y+1))-...
            1*V((x+1),(y-1))-2*V((x+1),y)-1*V((x+1),(y+1))).^2);        

    end
end
W=uint8(W);
%figure, imshow(W);


R=[];
c=0;
for m=1:5:k
    for n=1:5:l
     a=0;
     b=0;
        if (((m+4) < k) && ((n+4) < l)) 
        
         for i=m:(m+4)
             for j=n:(n+4)
                W(i,j);
                a=a+W(i,j);
             end
         end
            b=a/25;
            c=c+1;
            R=[R b];
        end
    end
end
R;
%figure, plot(R)


%NYARI EUCLEDIAN DISTANCE

D=(double(D))';
P=(double(P))';
R=(double(R))';

    xw11=(D-R).^2;
    xx1=sum(xw11);
    xx=sqrt(xx1)
    
    xw21=(P-R).^2;
    xx2=sum(xw21);
    xxx=sqrt(xx2)
  
%NYARII Block distance
xa2=abs(D-R)';
xb2=abs(P-R)';
xa_2=sum(xa2)
xb_2=sum(xb2)
 

if (xx<xxx && xa_2<xb_2)
    disp('Citra Uji, masuk dalam kelas 1');
else if (xx>xxx && xa_2>xb_2)
    disp('Citra Uji, masuk dalam kelas 2');
    end
end



subplot(3, 1, 1), plot (D), title('Vektor Ciri Citra Kelas 1')
subplot(3, 1, 2), plot (P), title('Vektor Ciri Citra Kelas 2')
subplot(3, 1, 3), plot (R), title('Vektor Ciri Citra Uji')