% Telapak Tangan Kanan Bagian Dalam

clc;
clear all;

X1=[];
X2=[];
UJI1=[];
UJI2=[];

O=5;
P=O-1;
r=O*O;

sdirectory = 'images';
namafile = dir([sdirectory  '/', ['kaki_small_', '*.bmp']]);
for z = 1:length(namafile)
    filename = [sdirectory '/' namafile(z).name];
    img = imread(filename);
    %figure, imshow(img);
    
    R=img(:,:,1);
    G=img(:,:,2);
    B=img(:,:,3);

	%gray scale
    gray=(0.299*R)+(0.586*G)+(0.114*B);
    %gray=(0.333*R)+(0.333*G)+(0.333*B);
    %figure, imshow(gray);
    imwrite(gray, [sdirectory '/', ['gray_', namafile(z).name]]);
    
    G = drgaussian(gray, 50); 
    figure, imshow(G);
    
end,