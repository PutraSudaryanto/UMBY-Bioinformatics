clear all;clc;

A=imread('data_uji/kurp2.bmp');

R = A(:,:,1);
G = A(:,:,2);
B = A(:,:,3);
%YUV
M = (0.299*R)+(0.587*G)+(0.114*B);
[m,n]=size(M);

%invers
for i=1:m,
    for j=1:n,
        cb(i,j)=255-M(i,j);
    end,
end,

%kontras
for i=1:m,
    for j=1:n,
        cb1(i,j)=cb(i,j);
        if (cb1(i,j)>255)
            cb2(i,j)=255;
        else
            cb2(i,j)=cb1(i,j);
        end,
    end,
end,
figure, imshow(cb2)
[a, b] = size(cb2);

% Hitung frekuensi aras keabuan
L = 256;
Frek = zeros(L,1);
F = double(cb2);
for i = 1 : a
    for j = 1 : b
        intensitas = F(i,j); 

        Frek(intensitas+1) = Frek(intensitas+1) + 1;
    end
end
%Frek
% Hitung probabilitas
jum_piksel = a * b;
for i=0 : L-1
    Prob(i+1) = Frek(i+1) / jum_piksel;
end
%Prob
% Hitung mu
mu = 0;
for i=0 : L-1
    mu = mu + i * Prob(i+1);    
end

% Hitung deviasi standar
varians = 0;
for i=0 : L-1
   varians = varians + (i - mu)^2 * Prob(i+1);    
end

deviasi = sqrt(varians);
varians_n = varians / (L-1)^2; % Normalisasi

% Energi (Keseragaman)
energi = 0;
for i=0 : L-1
   energi = energi + Prob(i+1)^2;    
end

% Hitung R atau Smoothness
smoothness = 1 - 1 / (1 + varians_n);

mu;
deviasi;
energi;
smoothness;

% --------------- Warna -------------
RGB = double(A);
[m,n,d] = size(A);
% Rata2
jum_r=0;
jum_g=0;
jum_b=0;
jum_piksel = m * n;
for baris = 1:m
    for kolom = 1:n
          jum_r = jum_r + RGB(baris, kolom, 1);
          jum_g = jum_g + RGB(baris, kolom, 2);
     end
end
% Hitung rerata
mean_r = jum_r / jum_piksel;
mean_g = jum_g / jum_piksel;

data=[mu deviasi energi smoothness mean_r mean_g];
% ===================================================== %
% UJI CIRI EUCLEDIAN
% ===================================================== %
x = load('data_latih.txt');
%x=[4 4 4 4; 5 5 5 5 ;
%    6 6 6 6; 6 7 6 6];
%data1=[4 4 4 4];
[m,n]=size(x);

C=[];
ET=[];
for c=1:m,
    for d=1:n,
        % Euclidean
        D(c,d)= sqrt(abs(x(c,d)-data(1,d)).^2);
        % City Block
        CT(c,d)= abs(x(c,d)-data(1,d));
    end
    C=D;
    ET=CT;
end

for g=1:4,
    for h=1:n,
        % Euclidean
        K(g,h)=C(g,h);
        % City Block
        O(g,h)=ET(g,h);
    end
end

r=5;
for e=1:4,
    for f=1:n,
        % Euclidean
        L(e,f)=C(r,f);
        % City Block
        P(e,f)=ET(r,f);
    end
    r=r+1;
end

x
data
C
K
L
% Euclidean
fv=min(K)
fw=min(L)
if (fv<fw)
    disp ('Euclidean: Dikenali sebagai Kurap')
else
    disp ('Euclidean: Dikenali sebagai Kulit Normal')
end
% City Block
cv=min(O);
cw=min(P);
if (cv<cw)
    disp ('City Block: Dikenali sebagai Kurap')
else
    disp ('City Block: Dikenali sebagai Kulit Normal')
end