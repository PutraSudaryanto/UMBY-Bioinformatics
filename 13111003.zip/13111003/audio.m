clear all
clc

%kelas 1
data=wavread('doremi_rudi.wav');
dt=data(:,1);
yptg= dt(12201:12300,:)';


%kelas2
data2=wavread('doremi_evi.wav');
dt2=data2(:,1);
yptg2= dt2(15201:15300,:)';

%uji
data3=wavread('nyanyi_evi.wav');
dt3=data3(:,1);
yptg3= dt3(11201:11300,:)';

%Pencocokan dengan euclidean distance
xa=abs(yptg-yptg3);
xb=abs(yptg2-yptg3);
disp('euclidean distance objek uji dengan kelas 1')
xa_1=sqrt(xa*xa')
disp('euclidean distance objek uji dengan kelas 2')
xb_1=sqrt(xb*xb')

%Pencocokan dengan Block distance
xa2=abs(yptg-yptg3);
xb2=abs(yptg2-yptg3);
p=ones(100,1);
disp('block distance objek uji dengan kelas 1')
xa_2=xa2*p
disp('block distance objek uji dengan kelas 2')
xb_2=xb2*p

%seleksi
if (xa_1<xb_1 && xa_2<xb_2)
    disp('Objek uji masuk dalam kelas 1')
else
    disp('Objek uji masuk dalam kelas 2')
end

subplot(3, 1, 1), plot(yptg), title('kelas 1')
subplot(3, 1, 2), plot(yptg2), title('kelas 2')
subplot(3, 1, 3), plot(yptg3), title('objek uji')