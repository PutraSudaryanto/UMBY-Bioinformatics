clear all;
clc;
E=imread('KR2.jpg');
R=E(:,:,1);
G=E(:,:,2);
B=E(:,:,3);

Gray=0.229*R+0.548*G+0.114*B;
[A,B]=size(Gray);
for i=1:A,
    for j=1:B,
        y=Gray(i,j);
        if(y>140);
            TH(i,j)=0;
        else
            TH(i,j)=1;
        end;
    end;
end;

C=double(TH);
[K,F]=size(TH);
for i=1:K,
    for j=1:F,
        image=Gray(i,j);
        if(image > 100 && image < 140)
            tb(i,j)=1;
        else
            tb(1,j)=0;
        end;
    end,
end,
deteksitebing = tb;

for i=1:size(C,1)-2
    for j=1:size(C,2)-2
        %Sobel mask for x-direction:
        Gx=((2*C(i+2,j+1)+C(i+2,j)+C(i+2,j+2))-(2*C(i,j+1)+C(i,j)+C(i,j+2)));
        %Sobel mask for y-direction:
        Gy=((2*C(i+1,j+2)+C(i,j+2)+C(i+2,j+2))-(2*C(i+1,j)+C(i,j)+C(i+2,j)));
     
        %The gradient of the image
        TH(i,j)=sqrt(Gx.^2+Gy.^2);
     
    end
end
%%%%%%  menghitung rerata &%%%%%%%%%
V=[];
jml=0;
for i=1:A
    for j=1:B
        if TH(i,j)>0;
            v=TH(i,j);        
            V=[V v];            
        end
    end
end

for k=1:length(V)
   jml=jml+uint64(V(k));
end
rerata=double(jml)/double(length(V))

%%%%%%% menghitung standar deviasi%%%%%%%
Z=0;
W=jml^2;
N=length(V);
for k=1:length(V)
    Z=Z+uint64(V(k))^2;   
end
std=sqrt(double((((N*Z)-W)/(N*(N-1)))))

fv=[rerata std]
subplot(1,3,1), imshow(E);
title('Citra Asli');
subplot(1,3,2), imshow(tb);
title('Deteksi Tebing');
subplot(1,3,3), imshow(TH);
title('Sobel');
%% baca data uji
UJIAN = load('data.txt');
satu = 1:5;
dua  = 6:10;
n = length(satu); % jumlah data masing2 kelas
[r,c]=size(UJIAN);

%% mencari rata2 dan standar deviasi
rata1 = abs(sum(UJIAN(satu,:))/n)
rata2 = abs(sum(UJIAN(dua,:))/n)

rata = [rata1 rata2];

% Euclidean
m1=(double(rata1))';
m2=(double(rata2))';
x=(double(fv))';

xx11=(x-m1).^2;
xx1=sum(xx11);
xxw1=sqrt(abs(xx1));

xx12=(x-m2).^2;
xx2=sum(xx12);
xxw2=sqrt(abs(xx2));

% chebyshev distance

yy1=max(abs(x-m1));
yy2=max(abs(x-m2));

C1=[xxw1 yy1]
C2=[xxw2 yy2]

if (C1 < C2)
    disp('uji, masuk dalam kelas 1');
else
    disp('uji, masuk dalam kelas 2');
end


